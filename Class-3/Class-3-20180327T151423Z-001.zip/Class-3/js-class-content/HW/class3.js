var data = [
    {
        "Name": "ksadjfk",
        "Roll": "123421",
        "Department": "sadf"
    },
    {
        "Name": "ksafdsffdjfk",
        "Roll": "1234df21",
        "Department": "dsff"
    }
]

var selRow = document.getElementById("selectRow");
var row = data.length;

for(var i=0;i<row;i++){
    var opt = document.createElement('option');
    opt.textContent = i+1;
    selRow.appendChild(opt);
}

selRow.setAttribute("id", "Rowno");

var selClm = document.getElementById("selectColumn");


var column=0;
for(var key in data[0]) column++;

for(var i=0;i<column;i++){
    var opt = document.createElement('option');
    opt.textContent = i+1;
    selClm.appendChild(opt);
}

selClm.setAttribute("id", "Colno");


